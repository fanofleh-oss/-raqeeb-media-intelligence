import { NextRequest, NextResponse } from "next/server";
import * as cheerio from "cheerio";
import dns from "node:dns/promises";
import net from "node:net";

export const runtime = "nodejs";
function privateIp(ip:string){
  if(net.isIP(ip)===4){const p=ip.split(".").map(Number);return p[0]===10||p[0]===127||p[0]===0||(p[0]===169&&p[1]===254)||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168)||p[0]>=224;}
  return ip==="::1"||ip==="::"||ip.startsWith("fc")||ip.startsWith("fd")||ip.startsWith("fe80:");
}
async function safe(raw:string){
  let u:URL; try{u=new URL(raw)}catch{return null}
  if(!["http:","https:"].includes(u.protocol)||u.username||u.password)return null;
  const addrs=await dns.lookup(u.hostname,{all:true}).catch(()=>[]);
  if(!addrs.length||addrs.some(a=>privateIp(a.address)))return null;
  return u;
}
export async function POST(req:NextRequest){
  try{
    const {url}=await req.json(); const u=await safe(String(url||""));
    if(!u)return NextResponse.json({error:"URL غير مسموح أو غير صالح"},{status:400});
    const r=await fetch(u,{redirect:"manual",headers:{"User-Agent":"RAQEEB-Research/1.0"},signal:AbortSignal.timeout(12000)});
    if(r.status>=300&&r.status<400){
      const loc=r.headers.get("location"); if(!loc)return NextResponse.json({error:"Redirect غير صالح"},{status:400});
      const target=new URL(loc,u); const ok=await safe(target.toString());
      if(!ok)return NextResponse.json({error:"Redirect غير مسموح"},{status:400});
      const rr=await fetch(ok,{headers:{"User-Agent":"RAQEEB-Research/1.0"},signal:AbortSignal.timeout(12000)});
      return parse(rr);
    }
    return parse(r);
  }catch(e:any){return NextResponse.json({error:"تعذر استخراج الصفحة: "+String(e?.message||e).slice(0,160)},{status:400})}
}
async function parse(r:Response){
  const ct=r.headers.get("content-type")||""; if(!ct.includes("text/html"))return NextResponse.json({error:"المصدر ليس صفحة HTML"},{status:400});
  const raw=(await r.text()).slice(0,2_000_000); const $=cheerio.load(raw); $("script,style,nav,footer,form,noscript,svg").remove();
  const title=($("title").first().text().trim()||r.url).slice(0,500);
  const text=$("h1,h2,p").map((_,e)=>$(e).text().replace(/\s+/g," ").trim()).get().filter(Boolean).join("\\n").slice(0,120000);
  return NextResponse.json({title,url:r.url,text});
}