import { NextRequest, NextResponse } from "next/server";
export const runtime="nodejs";
export async function POST(req:NextRequest){
  const key=process.env.OPENAI_API_KEY, model=process.env.OPENAI_MODEL;
  if(!key||!model)return NextResponse.json({error:"AI غير مهيأ على الخادم. أضف OPENAI_API_KEY و OPENAI_MODEL في Vercel."},{status:503});
  try{
    const body=await req.json(), c=body.case||{}, sources=(c.sources||[]).slice(0,20);
    const corpus=sources.map((s:any,i:number)=>`[S${i+1}] ${s.title||""}\n${String(s.text||"").slice(0,18000)}`).join("\\n\\n");
    const prompt=`You are assisting a professional media analyst using RAQEEB.
Analyze only supplied evidence. Distinguish observation, signal, hypothesis, and corroborated finding.
Do not infer deception, coordination, intent, or causality merely from correlation, timing, repetition, anonymous sourcing, or missing evidence.
Explicitly identify counterevidence, alternative explanations, intelligence gaps, and what would change the assessment.
Cite supplied sources as [S1], [S2], etc. Never invent citations. Do not output a deception probability or truth score.
Return concise sections: Executive Assessment; Key Judgments; Contradictions; Source/Independence Caveats; Competing Hypotheses; Intelligence Gaps; Verification Priorities; Confidence & Limitations.
Case: ${c.title||""}
Question: ${c.question||""}
Sources:
${corpus}`;
    const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model,input:prompt}),signal:AbortSignal.timeout(90000)});
    const j:any=await r.json();
    if(!r.ok)return NextResponse.json({error:j?.error?.message||"AI request failed"},{status:400});
    let text=j.output_text||"";
    if(!text)text=(j.output||[]).flatMap((o:any)=>o.content||[]).filter((x:any)=>x.type==="output_text").map((x:any)=>x.text||"").join("\\n");
    return NextResponse.json({text:text||"No text returned."});
  }catch(e:any){return NextResponse.json({error:String(e?.message||e).slice(0,200)},{status:400})}
}