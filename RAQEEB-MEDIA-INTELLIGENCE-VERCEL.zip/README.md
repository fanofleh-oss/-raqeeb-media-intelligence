# RAQEEB | رقيب — Media Intelligence Workspace

RAQEEB is a Vercel-ready analytical workspace for journalists and media researchers. It helps organize cases, collect sources, review claims through a structured 9-dimension / 45-question framework, compare competing hypotheses, and generate an evidence-grounded AI analytical brief.

## Deploy on Vercel
1. Import this GitHub repository into Vercel.
2. In **Project Settings → Environment Variables**, add:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL`
3. Redeploy the project.
4. Open the Vercel URL. Users do not see the API key.

## Included
- Premium Arabic-first analytical workspace
- Case archive
- Source URL extraction and direct source links
- 9 analytical dimensions / 45 structured questions
- Evidence notes and analyst assessment
- Competing hypotheses
- AI-assisted analytical brief
- Local browser persistence
- JSON backup/export

## Data model for this edition
Cases are stored in the browser's local storage on each device. This keeps the evaluation build simple and avoids a central case database. Different devices do not automatically share cases.

## Security note
Never commit API keys to GitHub. Configure them only through Vercel Environment Variables. For confidential newsroom deployment, add authentication, access controls, encryption, audit logs, rate limits, and an approved shared-storage model before entering sensitive material.

## Methodological principle
RAQEEB does not label a story true or false by a single automated score. Signals are treated as prompts for investigation and should be tied to evidence, counterevidence, alternative explanations, and analyst confidence.
